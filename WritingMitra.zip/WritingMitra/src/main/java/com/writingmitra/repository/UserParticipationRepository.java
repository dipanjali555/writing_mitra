package com.writingmitra.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.writingmitra.model.Participation;

public interface UserParticipationRepository 
        extends JpaRepository<Participation, Integer> {

}