package com.writingmitra.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.writingmitra.mapper.FeedBackMapper;
import com.writingmitra.model.Feedback;

@Repository
public class CommonRepository {
	@Autowired
	 private JdbcTemplate jdbcTemplate;
	
//	public List<Feedback> fetchFeedback() 
//	{
//		String sql = "select * from feedback order by id desc limit 10";
//		
//	List<Feedback>feedbackList =	jdbcTemplate.query(sql, new FeedBackMapper()); 
//	
//	return feedbackList;
//		
//	}
	
	
	public List<Feedback> fetchFeedback() 
	{
		//user table-> u
		// feedback table-> f
		
		
		String sql = "select u.name ,f.rating, f.review from users u, feedback f where u.email=f.email order by f.id desc limit 10";
		
	List<Feedback>feedbackList =jdbcTemplate.query(sql, new FeedBackMapper()); 
	
	return feedbackList;
		
	}


}
