package com.writingmitra.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.writingmitra.mapper.BlogMapper;
import com.writingmitra.model.Blog;

@Repository
public class UserBlogRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<Blog> fetchBlog(String category) {

        
    	 List<Blog> blogList=null;
    	String sql = "select u.name ,b.email, b.title, b.content, b.category from users u, blog b where u.email = b.email  and b.category=?";

      try {
        
blogList  =  jdbcTemplate.query(sql,  new BlogMapper(),category);
        
      }
      
     
      
      catch (Exception e) {
		// TODO: handle exception
	}
   						

        return blogList;
    }
}