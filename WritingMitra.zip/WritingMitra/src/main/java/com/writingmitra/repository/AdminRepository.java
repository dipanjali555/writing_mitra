package com.writingmitra.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.writingmitra.model.Admin;

public interface AdminRepository extends JpaRepository<Admin, String>{
	

}
