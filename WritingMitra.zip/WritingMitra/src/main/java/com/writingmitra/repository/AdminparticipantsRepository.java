package com.writingmitra.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.writingmitra.mapper.UserParticipationMapper;
import com.writingmitra.model.Participation;

@Repository
public class AdminparticipantsRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    
    public List<Participation> allParticipants(Integer compId) {

        String sql = "SELECT p.p_id, p.comp_id, p.title, p.content, p.email, p.phone, p.p_status, p.winner, " +
                     "u.name, u.city, u.phone AS user_phone, u.profile_pic, u.description " +
                     "FROM participation p " +
                     "JOIN users u ON p.email = u.email " +
                     "WHERE p.comp_id = ?";

        return jdbcTemplate.query(sql, new UserParticipationMapper(), compId);
    }

    
    public void markWinner(int pId) {

        String getCompId = "SELECT comp_id FROM participation WHERE p_id = ?";
        Integer compId = jdbcTemplate.queryForObject(getCompId, new Object[]{pId}, Integer.class);

        if (compId != null) {

            
            String reset = "UPDATE participation SET winner = NULL WHERE comp_id = ?";
            jdbcTemplate.update(reset, compId);

            // Set selected winner
            String update = "UPDATE participation SET winner = 'Winner' WHERE p_id = ?";
            jdbcTemplate.update(update, pId);
        }
    }

    	
    public void resetWinner(Integer compId) {
        String sql = "UPDATE participation SET winner = NULL WHERE comp_id = ?";
        jdbcTemplate.update(sql, compId);
    }

    public List<Participation> allWinners() {

        String sql = "SELECT p.p_id, p.comp_id, p.title, p.content, p.email, p.phone, p.p_status, p.winner, " +
                     "u.name, u.city, u.phone AS user_phone, u.profile_pic, u.description " +
                     "FROM participation p " +
                     "JOIN users u ON p.email = u.email " +
                     "WHERE p.winner = 'Winner'";

        return jdbcTemplate.query(sql, new UserParticipationMapper());
    }
}