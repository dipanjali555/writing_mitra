package com.writingmitra.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.writingmitra.model.Blog;

@Repository
public interface BlogRepository extends JpaRepository<Blog, Integer> {
	public List<Blog> findByEmail(String email);

}