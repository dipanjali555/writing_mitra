package com.writingmitra.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.writingmitra.model.Admin; 
import com.writingmitra.model.CompetitionNotice;
import com.writingmitra.model.Contact;
import com.writingmitra.model.Feedback;
import com.writingmitra.model.Participation;
import com.writingmitra.model.User;
import com.writingmitra.service.AdminService;

@RestController
@RequestMapping("/admin")
@CrossOrigin("*")
public class AdminController {

    @Autowired
    private AdminService service;

    // Admin login
    @PostMapping("/login")
    public String loginAdmin(@RequestBody Admin admin) {
        return service.loginAdmin(admin);
    }

    // Contacts
    @GetMapping("/contacts")
    public List<Contact> getContacts() {
        return service.getAllContacts();
    }

    // Feedback
    @GetMapping("/feedbacks")
    public List<Feedback> getFeedbacks() {
        return service.getAllFeedback();
    }

    @DeleteMapping("/feedback/{id}")
    public String deleteFeedback(@PathVariable Integer id) {
        service.deleteFeedback(id);
        return "Feedback Deleted";
    }

    // Competition Notices
    @PostMapping("/notice")
    public String addNotice(@RequestBody CompetitionNotice notice) {
        return service.addNotice(notice);
    }

    @GetMapping("/notices")
    public List<CompetitionNotice> getNotices() {
        return service.getAllNotices();
    }

    // Participants
    @GetMapping("/participants/{id}")
    public ResponseEntity<List<Participation>> getParticipants(@PathVariable Integer id) {
        List<Participation> participants = service.allParticipants(id);
        return ResponseEntity.ok(participants);
    }

    // Mark Winner
    @PostMapping("/markWinner/{pId}")
    public String markWinner(@PathVariable Integer pId) {
        service.markWinner(pId);
        return "Participant marked as Winner!";
    }
    
    @PostMapping("/registration")
    public String registration(@RequestBody Admin admin) {
        return service.registration(admin);
    }
}