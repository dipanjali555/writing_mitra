package com.writingmitra.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.writingmitra.dto.UserDTO;
import com.writingmitra.dto.PasswordDTO;
import com.writingmitra.model.Feedback;
import com.writingmitra.model.User;
import com.writingmitra.model.Blog;
import com.writingmitra.model.CompetitionNotice;
import com.writingmitra.model.Participation;
import com.writingmitra.service.UserService;

@RestController
@RequestMapping("/user")
@CrossOrigin("*")
public class UserController {

    @Autowired
    private UserService service;

   
    @PostMapping("/registration")
    public String registration(@RequestBody User user) {
        return service.registration(user);
    }
    
    //code for emaiExatence
    @GetMapping("/checkEmail/{email}")
    public String checkEmail( @PathVariable(name="acd")String email)
    {
    	System.out.println(email);
    	return service.checkEmail(email);
    }
    
    
    

    @PostMapping("/login")
    public String login(@RequestBody User user) {
        return service.loginUser(user);
    }

   
    @PostMapping("/addBlog")
    public Blog addBlog(@RequestBody Blog blog) {
        return service.postBlog(blog);
    }

    @GetMapping("/blogs")
    public List<Blog> getBlogs() {
        return service.fetchBlog("");
    }

    @GetMapping("/blogs/category/{category}")
    public List<Blog> getByCategory(@PathVariable String category) {
        return service.fetchBlog(category);
    }

    @GetMapping("/blogs/email/{email}")
    public List<Blog> getByEmail(@PathVariable String email) {
        return service.getBlogsByEmail(email);
    }

    
    @GetMapping("/profile/{email}")
    public User getProfile(@PathVariable String email) {
        return service.getProfile(email);
    }

    @PutMapping("/edit/{email}")
    public String editProfile(@PathVariable String email, @RequestBody UserDTO dto) {
        return service.editProfile(email, dto);
    }

    @PatchMapping("/password/{email}")
    public String updatePassword(@PathVariable String email, @RequestBody PasswordDTO dto) {
        return service.updatePassword(email, dto);
    }

    @PostMapping("/uploadPic")
    public Map<String, String> uploadPic(
            @RequestPart("profileImageDetail") User user,
            @RequestPart("imageFile") MultipartFile imageFile) {

        return service.uploadPic(user, imageFile);
    }

    
    @PostMapping("/feedback")
    public String feedback(@RequestBody Feedback feedback) {
        return service.feedback(feedback);
    }

    @GetMapping("/allFeedback")
    public List<Feedback> allFeedback() {
        return service.allFeedback();
    }

    @DeleteMapping("/deleteFeedback/{id}")
    public void deleteFeedback(@PathVariable Integer id) {
        service.deleteFeedback(id);
    }

   
    @GetMapping("/notice")
    public List<CompetitionNotice> getNotice() {
        return service.AllNotice();
    }

    
    @PostMapping("/participate")
    public String participate(@RequestBody Participation participation) {
        System.out.println("CompID Received: " + participation.getCompId());
        return service.participate(participation);
    }

    @GetMapping("/participations")
    public List<Participation> getAllParticipations() {
        return service.getAllParticipations();
    }

    
    @GetMapping("/winners")
    public List<Participation> getWinners() {
        return service.getAllWinners();
    }
}