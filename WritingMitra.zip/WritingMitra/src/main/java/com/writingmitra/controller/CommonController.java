package com.writingmitra.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.writingmitra.model.Contact;
import com.writingmitra.model.Feedback;
import com.writingmitra.service.CommonService;

@RestController
@CrossOrigin("*")
public class CommonController {

    @Autowired
    private CommonService commonService;

    @PostMapping("/addContact")
    public Contact saveContact(@RequestBody Contact contact) {
        return commonService.addContact(contact);
    }
    
    @GetMapping("/fetchFeedback")
    public ResponseEntity<List<Feedback>>fetchFeedback() 
   {
   	 List<Feedback>fList=commonService.fetchFeedback();
   	 
   	 System.out.print(fList);
   	 return ResponseEntity.ok(fList);
   }
    
    
    
}