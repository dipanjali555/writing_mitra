package com.writingmitra.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.writingmitra.model.Blog;
import com.writingmitra.model.User;

public class BlogMapper implements RowMapper<Blog> {

    Blog blog = null;

    @Override
    public Blog mapRow(ResultSet rs, int rowNum) throws SQLException {

        
        String title = rs.getString("title");
        String content = rs.getString("content");
        String category = rs.getString("category");
        String email = rs.getString("email");

        
        String userName = rs.getString("name");

        
        User u = new User();
        u.setName(userName);

        
        blog = new Blog();
        blog.setTitle(title);
        blog.setContent(content);
        blog.setCategory(category);
        blog.setEmail(email);
        blog.setUser(u);

        return blog;
    }
}
