package com.writingmitra.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.writingmitra.model.Participation;
import com.writingmitra.model.User;

public class UserParticipationMapper implements RowMapper<Participation> {

    @Override
    public Participation mapRow(ResultSet rs, int rowNum) throws SQLException {
        Participation participate = new Participation();

        participate.setPId(rs.getInt("p_id"));
        participate.setCompId(rs.getInt("comp_id"));
        participate.setTitle(rs.getString("title"));
        participate.setContent(rs.getString("content"));
        participate.setEmail(rs.getString("email"));
        participate.setPhone(rs.getString("phone"));
        participate.setPStatus(rs.getString("p_status"));
        participate.setWinner(rs.getString("winner"));

        // User info for frontend
        User user = new User();
        user.setName(rs.getString("name"));
        user.setCity(rs.getString("city"));
        user.setPhone(rs.getString("user_phone"));
        user.setProfilePic(rs.getString("profile_pic"));
        user.setDescription(rs.getString("description"));

        participate.setUser(user);

        return participate;
    }
}