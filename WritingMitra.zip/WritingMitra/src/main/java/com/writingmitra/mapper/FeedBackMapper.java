package com.writingmitra.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.writingmitra.model.Feedback;
import com.writingmitra.model.User;

public class FeedBackMapper  implements RowMapper<Feedback>
{
	
	Feedback feedback=null;

	@Override
	public Feedback mapRow(ResultSet rs, int rowNum) throws SQLException {
//		System.out.print(rowNum);
//		String email = rs.getString("email");
//		String rating = rs.getString("rating");
//		String review = rs.getString("review");
//		//creating object of feedback class
//		
//		feedback= new Feedback(email, review, rating);
		
		//fetcing
		String rating = rs.getString("rating");
		String review = rs.getString("review");
		
		String userName = rs.getString("name");
		
		//user has a name
		// feedback has user
		//user class object creation
		
		User u =new User();
		u.setName(userName);
		
		feedback = new Feedback();
		feedback.setRating(rating);
		feedback.setReview(review);
		feedback.setUser(u);
		
//		
		
		
		
		
		
		
		
		return feedback;
	}

}
