package com.writingmitra.model;

import jakarta.persistence.*;

@Entity
@Table(name = "participation")
public class Participation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // ✅ FIX
    @Column(name = "p_id")
    private Integer pId;

    @Column(name = "comp_id")
    private Integer compId;

    @Column(name = "title", length = 100)
    private String title;

    @Column(name = "content", length = 500)
    private String content;

    @Column(name = "email", length = 45)
    private String email;

    @Column(name = "phone", length = 15)
    private String phone;

    @Column(name = "p_status", length = 45)
    private String pStatus;

    @Column(name = "winner", length = 45)
    private String winner;

    @Transient
    private User user;

    // Getters & Setters
    public Integer getPId() { return pId; }
    public void setPId(Integer pId) { this.pId = pId; }

    public Integer getCompId() { return compId; }
    public void setCompId(Integer compId) { this.compId = compId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getPStatus() { return pStatus; }
    public void setPStatus(String pStatus) { this.pStatus = pStatus; }

    public String getWinner() { return winner; }
    public void setWinner(String winner) { this.winner = winner; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
}