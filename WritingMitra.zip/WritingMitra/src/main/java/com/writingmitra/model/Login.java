package com.writingmitra.model;

public class Login {

    private String email;
    private String password;

    // Default Constructor (Very Important)
    public Login() {
    }

    // Getter and Setter Methods

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}