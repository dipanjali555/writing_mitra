package com.writingmitra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WritingMitraApplication {

	public static void main(String[] args) {
		SpringApplication.run(WritingMitraApplication.class, args);
//		System.out.println("Hello Boot");
//		System.out.println("hello Sts");
//		System.out.println("hello Sts1");
//		System.out.println("hello Sts2");
		
	}

}
