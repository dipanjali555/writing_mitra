package com.writingmitra.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.writingmitra.model.Admin;
import com.writingmitra.model.CompetitionNotice;
import com.writingmitra.model.Contact;
import com.writingmitra.model.Feedback;
import com.writingmitra.model.Participation;
import com.writingmitra.repository.AdminRepository;
import com.writingmitra.repository.AdminparticipantsRepository;
import com.writingmitra.repository.CompetitionNoticeRepository;
import com.writingmitra.repository.ContactRepository;
import com.writingmitra.repository.FeedbackRepository;

@Service
public class AdminService {

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private ContactRepository contactRepository;

    @Autowired
    private FeedbackRepository feedbackRepository;

    @Autowired
    private CompetitionNoticeRepository noticeRepo;

    @Autowired
    private AdminparticipantsRepository adparticipantsrepo;

    
    
    
    public String loginAdmin(Admin admin) {
        Optional<Admin> opt = adminRepository.findById(admin.getEmail());
        if (opt.isPresent()) {
            Admin a = opt.get();
            if (a.getPassword().equals(admin.getPassword()))
                return "success";
            else
                return "Invalid password";
        }
        return "Invalid Email";
    }

    
    public List<Contact> getAllContacts() {
        return contactRepository.findAll();
    }

    
    public List<Feedback> getAllFeedback() {
        return feedbackRepository.findAll();
    }

    public void deleteFeedback(Integer id) {
        feedbackRepository.deleteById(id);
    }

    
    public String addNotice(CompetitionNotice notice) {
        noticeRepo.save(notice);
        return "Notice Added";
    }

    public List<CompetitionNotice> getAllNotices() {
        return noticeRepo.findAll();
    }

    
    public List<Participation> allParticipants(Integer compId) {
        return adparticipantsrepo.allParticipants(compId);
    }

    
    public void markWinner(Integer pId) {
        adparticipantsrepo.markWinner(pId);
    }
    
    public String registration(Admin admin) {
        adminRepository.save(admin);
        return "Admin registered successfully";
    }
    
    
}