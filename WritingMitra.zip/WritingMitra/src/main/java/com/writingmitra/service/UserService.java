package com.writingmitra.service;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.writingmitra.dto.PasswordDTO;
import com.writingmitra.dto.UserDTO;
import com.writingmitra.model.Blog;
import com.writingmitra.model.CompetitionNotice;
import com.writingmitra.model.Feedback;
import com.writingmitra.model.Participation;
import com.writingmitra.model.User;
import com.writingmitra.repository.AdminparticipantsRepository;
import com.writingmitra.repository.BlogRepository;
import com.writingmitra.repository.CompetitionNoticeRepository;
import com.writingmitra.repository.FeedbackRepository;
import com.writingmitra.repository.UserBlogRepository;
import com.writingmitra.repository.UserParticipationRepository;
import com.writingmitra.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private FeedbackRepository feedbackRepository;

    @Autowired
    private BlogRepository blogRepository;

    @Autowired
    private UserBlogRepository userBlogRepository;

    @Autowired
    private CompetitionNoticeRepository noticeRepo;

    @Autowired
    private UserParticipationRepository participationRepo;

    
    @Autowired
    private AdminparticipantsRepository adparticipantsrepo;

    
    public String registration(User user) {
        userRepository.save(user);
        return "User registered successfully";
    }

    public String loginUser(User user) {
        Optional<User> opt = userRepository.findById(user.getEmail());

        if (opt.isPresent()) {
            User u = opt.get();
            if (u.getPassword().equals(user.getPassword()))
                return "success";
            else
                return "Invalid password";
        }
        return "Invalid Email";
    }

   
    public User getProfile(String email) {
        return userRepository.findById(email).orElse(null);
    }

    public String editProfile(String email, UserDTO dto) {
        Optional<User> opt = userRepository.findById(email);

        if (opt.isPresent()) {
            User user = opt.get();
            user.setName(dto.getName());
            user.setPhone(dto.getPhone());
            user.setCity(dto.getCity());
            userRepository.save(user);
            return "updated";
        }
        return "not found";
    }

    public String updatePassword(String email, PasswordDTO dto) {
        Optional<User> opt = userRepository.findById(email);

        if (opt.isPresent()) {
            User user = opt.get();

            if (user.getPassword().equals(dto.getOldpass())) {
                user.setPassword(dto.getNewpass());
                userRepository.save(user);
                return "Password Updated";
            } else {
                return "Old Password Incorrect";
            }
        }
        return "User Not Found";
    }

   
    public Blog postBlog(Blog blog) {
        return blogRepository.save(blog);
    }

    public List<Blog> fetchBlog(String category) {
        return userBlogRepository.fetchBlog(category);
    }

    public List<Blog> getBlogsByEmail(String email) {
        return blogRepository.findByEmail(email);
    }

    
    public String feedback(Feedback feedback) {
        feedbackRepository.save(feedback);
        return "Feedback submitted";
    }

    public List<Feedback> allFeedback() {
        return feedbackRepository.findAll();
    }

    public void deleteFeedback(Integer id) {
        feedbackRepository.deleteById(id);
    }

    
    public List<CompetitionNotice> AllNotice() {
        return noticeRepo.findAll();
    }

    
    public String participate(Participation participation) {
        participationRepo.save(participation);
        return "success";
    }

    public List<Participation> getAllParticipations() {
        return participationRepo.findAll();
    }

    
    public List<Participation> getAllWinners() {
        return adparticipantsrepo.allWinners();
    }
    
    public String checkEmail(String email) {
    	String status="";
    	
    	 Optional<User>opt=userRepository.findById(email);
    	 
    	 if(opt.isPresent())
    	 {
    		 status="exists";
    		 
    	 }
    	 return status;
    	
    	
    }

   
    public Map<String, String> uploadPic(User user, MultipartFile imageFile) {

        Map<String, String> imageMap = new HashMap<>();

        try {
            String fileName = System.currentTimeMillis() + "_" + imageFile.getOriginalFilename();
            String uploadDir = System.getProperty("user.dir") + "/uploads/profileimages/";

            File targetFile = new File(uploadDir, fileName);
            imageFile.transferTo(targetFile);

            String imageURL = "http://localhost:9090/uploads/profileimages/" + fileName;

            Optional<User> opt = userRepository.findById(user.getEmail());

            if (opt.isPresent()) {
                User u = opt.get();
                u.setProfilePic(fileName);
                u.setDescription(user.getDescription());
                userRepository.save(u);

                imageMap.put("imageURL", imageURL);
                imageMap.put("email", u.getEmail());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return imageMap;
    }
}