package com.writingmitra.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import com.writingmitra.model.Contact;
import com.writingmitra.model.Feedback;
import com.writingmitra.repository.CommonRepository;
import com.writingmitra.repository.ContactRepository;

@Service
public class CommonService {

    @Autowired
    private ContactRepository contactRepository;
    @Autowired
    private CommonRepository commonRepository;

    public Contact addContact(Contact contact) {
        return contactRepository.save(contact);
    }
    
    public List<Feedback>fetchFeedback(){
    	 return commonRepository.fetchFeedback();
    }
    
    //view all feedback
    
}