package com.writingmitra.dto;


public class AdminDTO
{
	
	
	private String name,phone;
	 private String profilePic;
	
	

	public String getProfilePic() {
		return profilePic;
	}

	 public void setProfilePic(String profilePic) {
		 this.profilePic = profilePic;
	 }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public AdminDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AdminDTO(String name, String phone) {
		super();
		this.name = name;
		this.phone = phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
	

}
